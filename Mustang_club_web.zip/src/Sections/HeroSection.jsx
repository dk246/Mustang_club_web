import React from "react";

const HeroSection = () => {
  return <div>HeroSection</div>;
};

export default HeroSection;
