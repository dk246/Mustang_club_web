## DOWNLOAD CAR MODELS

### Model 1

```
Author: KOElkastasbers (https://sketchfab.com/koelkastasbers)
License: SKETCHFAB Standard (https://sketchfab.com/licenses)

Source: https://sketchfab.com/3d-models/2024-hyundai-santa-fe-a1ee29b80c844b13ba56ac7e28971a53

Title: 2024 Hyundai Santa Fe
```

### Model 2

```
Author: Ddiaz Design (https://sketchfab.com/ddiaz-design)
License: CC-BY-NC-SA-4.0 (http://creativecommons.org/licenses/by-nc-sa/4.0/)

Source: https://sketchfab.com/3d-models/2024-byd-sealion-7-4eb4a93ae47b47f4b213dd89a0ad89f0

Title: 2024 BYD Sealion 7

```
